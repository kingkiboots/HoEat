번호에 맞게 사진 첨부하였음

1. 이미지 다운로드 - webAPI 패키지 다운
2. 오라클 연동 - Database.Activity
3. 플로우 차트는 member_to_oracle -> board_to_excel -> pic_Download -> board_to_oracle

딜레이 땜시 시간이 1시간 - 1시간 30분 정도 걸려요. 틀어놓으시고 다른거 할 거 하세요!